function signUp(){
    window.location.href = '/collegeAdmission/signup';
;}

function logIn(){
    window.location.href = "/collegeAdmission/login";
}

function logOut(){
    window.location.href = "/collegeAdmission/login";


}